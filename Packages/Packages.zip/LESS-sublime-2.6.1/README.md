# Less syntax for Sublime Text 3

Provides syntax highlighting for `.less` (or `.css.less`) files, with

- snippets
- completions
- symbols

Highlights code using up to date specifications for properties and values to help you catch typos.

## Installation

This package is available through [Package Control](https://packagecontrol.io)


## Buy me a coffee 

☕️👌🏻

If you enjoy this package, feel free to make a little [donation via PayPal](https://paypal.me/pools/c/89Rcz97pIQ) towards the coffee that keeps this project running. It's much appreciated!
