<!--
This is a bug in the current implementation. Ideally should be fixed
in a rewrite using sublime-syntax format.
-->

<template>
  <div @click="foo => foo()"></div>
</template>
